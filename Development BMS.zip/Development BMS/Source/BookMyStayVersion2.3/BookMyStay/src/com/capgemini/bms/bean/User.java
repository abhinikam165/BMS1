package com.capgemini.bms.bean;

import java.io.Serializable;

import javax.persistence.*;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;


/**
 * The persistent class for the USERS database table.
 * 
 */
@Component
@Entity
@Table(name="USERS")
@NamedQuery(name="User.findAll", query="SELECT u FROM User u")
public class User implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="USERS_USERID_GENERATOR", sequenceName="USERS_SEQUENCE")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="USERS_USERID_GENERATOR")
	@Column(name="USER_ID")
	private int userId;

	@NotEmpty(message="Please Enter Address")
	@Pattern(regexp="[a-zA-Z0-9 //s]{1,50}",message="Please enter valid address")
	private String address;

	@Email(message="please enter valid email id")
	@NotEmpty(message="Please enter email")
	private String email;

	@NotEmpty(message="Please Enter Password")
	@Pattern(regexp="[a-zA-Z0-9 //s]{1,50}",message="Password should contain atleast one Capital letter and digit")
	private String password;

	
	@Column(name="PHN_NO")
	private BigDecimal phnNo;

	@Column(name="\"ROLE\"")
	private String role;


	@Column(name="USER_MOBILE_NO")
	private BigDecimal userMobileNo;

	@NotEmpty(message="Please Enter User Name")
	@Pattern(regexp="[a-zA-Z]{1,15}", message="Please enter valid user name")
	private String username;

	//bi-directional many-to-one association to BookingDetail
	@OneToMany(mappedBy="user")
	private List<BookingDetail> bookingDetails;

	public User() {
	}

	public int getUserId() {
		return this.userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public BigDecimal getPhnNo() {
		return this.phnNo;
	}

	public void setPhnNo(BigDecimal phnNo) {
		this.phnNo = phnNo;
	}

	public String getRole() {
		return this.role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public BigDecimal getUserMobileNo() {
		return this.userMobileNo;
	}

	public void setUserMobileNo(BigDecimal userMobileNo) {
		this.userMobileNo = userMobileNo;
	}

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public List<BookingDetail> getBookingDetails() {
		return this.bookingDetails;
	}

	public void setBookingDetails(List<BookingDetail> bookingDetails) {
		this.bookingDetails = bookingDetails;
	}

	public BookingDetail addBookingDetail(BookingDetail bookingDetail) {
		getBookingDetails().add(bookingDetail);
		bookingDetail.setUser(this);

		return bookingDetail;
	}

	public BookingDetail removeBookingDetail(BookingDetail bookingDetail) {
		getBookingDetails().remove(bookingDetail);
		bookingDetail.setUser(null);

		return bookingDetail;
	}

}