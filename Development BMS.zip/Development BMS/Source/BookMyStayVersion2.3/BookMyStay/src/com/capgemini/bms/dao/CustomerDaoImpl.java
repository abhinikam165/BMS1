package com.capgemini.bms.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capgemini.bms.bean.BookingDetail;
import com.capgemini.bms.bean.Hotel;
import com.capgemini.bms.bean.RoomDetail;
import com.capgemini.bms.bean.User;
import com.capgemini.bms.exception.HotelException;
import com.capgemini.bms.logger.HotelLogger;
@Repository
public class CustomerDaoImpl implements CustomerDao {
	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	User uBean;
	
	Logger logger = HotelLogger.getLoggerInstance();
	
	/****************************************************************************************
	 * @Function Name : registerUser
	 * @Input Parameters : user
	 * @Throws : HotelException
	 * @Description : To add user in the database
	 ****************************************************************************************/
	@Override
	public boolean registerUser(User uBean) throws HotelException {
		boolean flag=false;
		try
		{
			uBean.setRole("customer");
			entityManager.persist(uBean);
			flag = true;
			logger.info("INFO: User Registerd Sucessfully");
		}
		catch(Exception e)
		{
			logger.error("ERROR: Ubale to register user");
			throw new HotelException("Unable to Register. Please Try Again");
		}
		return flag;
	}

	/****************************************************************************************
	 * @Function Name : validate
	 * @Input Parameters : username,password
	 * @Return Type :String
	 * @Throws : HotelException
	 * @Description : Validate user using username and password
	 ****************************************************************************************/
	@Override
	public String validate(String username, String password) throws HotelException {
		String role="";
		Query query = entityManager.createQuery("SELECT user FROM User user");
		@SuppressWarnings("unchecked")
		ArrayList<User> user = (ArrayList<User>) query.getResultList();
		for(Object obj:user)
		{
			User var = (User)obj;
			if(username.equals(var.getUsername()) && password.equals(var.getPassword()))
			{
				logger.info("INFO: User Found And logged in successfully");
				role=var.getRole();
			}
		}
		System.out.println(role);
		if(role.equals(""))
		{
			logger.error("ERROR: Invalid Username OR Password.");
			throw new HotelException("Invalid Username OR Password. Please Try Again Or Signup");
		}
		return role;
	}

	/****************************************************************************************
	 * @Function Name : getHotelList
	 * @Input Parameters : city
	 * @Return Type : ArrayList<Hotel>
	 * @Throws : HotelException
	 * @Description : to get list of the hotel
	 ****************************************************************************************/
	@Override
	public ArrayList<Hotel> getHotelList(String city) throws HotelException {
		ArrayList<Hotel>list=new ArrayList<Hotel>();
		String qStr = "SELECT hotel FROM Hotel hotel WHERE hotel.hotelCity=:city";
		TypedQuery<Hotel> query = entityManager.createQuery(qStr, Hotel.class);
		query.setParameter("city", city);
		list=(ArrayList<Hotel>) query.getResultList();
		if(list.size()!=0)
		{
			logger.info("INFO: Fetched Hotel List");
		}
		else
		{
			logger.error("ERROR: Hotel List is Null");
		}
		return list;
	}

	@Override
	public ArrayList<RoomDetail> searchRooms(String roomTypes, long minPrice,long maxPrice, int hotelId) throws HotelException {
		
		return null;
	}
	/****************************************************************************************
	 * @Function Name : bookRoom
	 * @Input Parameters : BookingDetails
	 * @Return Type :boolean
	 * @Throws : HotelException
	 * @Description : To book a room
	 ****************************************************************************************/
	@Override
	public boolean bookRoom(BookingDetail bBean) throws HotelException {
		boolean flag = false;
		try
		{
			entityManager.persist(bBean);
			flag=true;
			logger.info("INFO: Room Booking Done");
		}
		catch(Exception e)
		{
			logger.error("ERROR:Unable to Book Room");
			throw new HotelException("Unable to Book Room Plaese try again.");
		}
		return flag;
	}

	/****************************************************************************************
	 * @Function Name : getUser
	 * @Input Parameters : username, password
	 * @Return Type :User
	 * @Throws : HotelException
	 * @Description : Used to get the details of user
	 ****************************************************************************************/
	@Override
	public User getUser(String username, String password) throws HotelException {
		String qStr = "SELECT user FROM User user WHERE user.username=:username AND user.password=:password";
		TypedQuery<User> query = entityManager.createQuery(qStr, User.class);
		query.setParameter("username", username);
		query.setParameter("password", password);
		User user=query.getSingleResult();
		logger.info("INFO: Fetched User Information");
		return user;
	}

	/****************************************************************************************
	 * @Function Name : getBooking
	 * @Input Parameters : userId
	 * @Return Type :ArrayList
	 * @Throws : HotelException 
	 * @Description : get booking details
	 ****************************************************************************************/
	@Override
	public ArrayList<BookingDetail> getBookings(int userId) throws HotelException {
		ArrayList<BookingDetail> bookingList=new ArrayList<BookingDetail>();
		String qStr = "SELECT booking FROM BookingDetail booking WHERE user.userId=:userId";
		TypedQuery<BookingDetail> query = entityManager.createQuery(qStr, BookingDetail.class);
		query.setParameter("userId", userId);
		bookingList=(ArrayList<BookingDetail>) query.getResultList();
		if(bookingList.size()!=0)
		{
			logger.info("INFO: Fetched Booking List");
		}
		else
		{
			logger.error("ERROR: Booking List is Null");
		}
		return bookingList;
	}

	@Override
	public ArrayList<BookingDetail> getAllBookings(int userId)
			throws HotelException {
		return null;
	}

	@Override
	public boolean cancelBooking(int bookingId) throws HotelException {
		return false;
	}

	@Override
	public Hotel getHotelById(int hotelId, String city) throws HotelException {
		return null;
	}

}
