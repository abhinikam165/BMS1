package com.capgemini.bms.logger;

import org.apache.log4j.Appender;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Layout;
import org.apache.log4j.Logger;
import org.apache.log4j.SimpleLayout;

public class HotelLogger {
	static Logger looger = Logger.getLogger(HotelLogger.class);
	static
	{
		Layout layout = new SimpleLayout();
		Appender appender =null;
		try
		{
			appender = new FileAppender(layout,"P://Users/swshedge/Desktop/EclipseWorkSpaceSpringProject/BookMyStay/log.txt");	
		}
		catch(Exception e)
		{
			System.out.println("Can not Instatiate Logger"+e.getMessage());
		}
		looger.addAppender(appender);
	}
	
	public static Logger getLoggerInstance()
	{
		return looger;
	}
}
