package com.capgemini.bms.exception;

public class HotelException extends Exception {
	private static final long serialVersionUID = 1L;
	String message;
	public HotelException(String message){
		this.message=message;
	}
	
	@Override
	public String getMessage() {
		return message;
	}
}
