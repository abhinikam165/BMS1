package com.capgemini.bms.dao;

import java.time.LocalDate;
import java.util.ArrayList;

import com.capgemini.bms.bean.BookingDetail;
import com.capgemini.bms.bean.Hotel;
import com.capgemini.bms.bean.RoomDetail;
import com.capgemini.bms.exception.HotelException;

public interface AdminDao {
	boolean addHotel(Hotel hotel) throws HotelException;
	ArrayList<Hotel> getHotelList() throws HotelException;
	Hotel getHotels(int hotelId) throws HotelException;
	boolean deleteHotel(int hotelId) throws HotelException;
	boolean updateHotel(Hotel hotelNew) throws HotelException;
	boolean addroom(RoomDetail room) throws HotelException;
	boolean updateRoom(int roomId) throws HotelException;
	boolean deleteRoom(int roomId) throws HotelException;
	ArrayList<Hotel> generateHotelListReport() throws HotelException;
	ArrayList<BookingDetail> generateSpecificDateBookingReport(LocalDate startDate,LocalDate endDate) throws HotelException;
	ArrayList<BookingDetail> generateSpecificHotelBookingReport(int hotelId) throws HotelException;
	ArrayList<RoomDetail> viewRooms(int hotelId) throws HotelException;
	RoomDetail getRoom(int roomId) throws HotelException;
	public boolean deleteRoomOnHotelId(Hotel bean) throws HotelException;
	public boolean deleteBookingOnRoom(int roomId) throws HotelException;
	public ArrayList<RoomDetail> viewRoomstoDelete(int hotelId) throws HotelException;
}
