package com.capgemini.bms.test;
import static org.junit.Assert.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import com.capgemini.bms.bean.Hotel;
import com.capgemini.bms.bean.RoomDetail;
import com.capgemini.bms.dao.AdminDao;
import com.capgemini.bms.dao.AdminDaoImpl;
import com.capgemini.bms.exception.HotelException;
import com.capgemini.bms.service.AdminServiceImpl;

public class TestAdminDaoImpl {

	AdminServiceImpl service;
	AdminDao dao;
	
	@Before
	public void init()
	{
		service = new AdminServiceImpl();
		dao = new AdminDaoImpl();
		service.setDao(dao);
	}

	@Test
	public void testAddHotel()throws HotelException {
		Hotel hotel = new Hotel();
		
		int avgRate= 1000;
		BigDecimal avgRateBD = new BigDecimal(avgRate);
		int rating= 4;
		BigDecimal ratingBD = new BigDecimal(rating);
		int fax= 987546589;
		BigDecimal faxBD = new BigDecimal(fax);
		int hotelPhnNo1 = 1234567891;
		BigDecimal hotelPhnNo1BD = new BigDecimal(hotelPhnNo1);
		int hotelPhnNo2 = 789854652;
		BigDecimal hotelPhnNo2BD = new BigDecimal(hotelPhnNo2);
		
		hotel.setHotelCity("Pune");
		hotel.setHotelName("Blue Moon");
		hotel.setHotelAddress("Pune");
		hotel.setHotelDesc("Good");
		hotel.setAvgRate(avgRateBD);
		hotel.setHotelPhnNo1(hotelPhnNo1BD);
		hotel.setHotelPhnNo2(hotelPhnNo2BD);
		hotel.setRating(ratingBD);
		hotel.setEmail("s@gmail.com");
		hotel.setFax(faxBD);
		
		assertEquals(true, service.addHotel(hotel));
	}

	@Test
	public void testGetHotelList() throws HotelException {
		assertNotEquals(0, service.getHotelList().size());
	}
	
	@Test
	public void testGetHotelList1() throws HotelException {
		assertNull(service.getHotelList().size());
	}

	@Test
	public void testGetHotels() throws HotelException {
		assertNotNull(service.getHotels(1001));
	}

	@Test
	public void testGetHotels1() throws HotelException {
		assertNotNull(service.getHotels(101));
	}
	
	@Test
	public void testDeleteHotel() throws HotelException{
		assertEquals(true, service.deleteHotel(1029));
	}
	@Test
	public void testDeleteHotel1() throws HotelException{
		assertEquals(true,service.deleteHotel(1028));
	}



	@Test
	public void testAddroom() throws HotelException{
		
		RoomDetail room=new RoomDetail();
		
		int roomNo= 765;
		BigDecimal roomNoBD = new BigDecimal(roomNo);
		
		room.setRoomNo(roomNoBD);
		room.setRoomType("delux");
		room.setPerNightRt(3000);
		room.setAvailability("y");
		
		assertEquals(true, service.addroom(room));
		
	}

	@Test
	public void testUpdateRoom() throws HotelException{
		
		RoomDetail room=new RoomDetail();
		
		int roomNo= 777;
		BigDecimal roomNoBD = new BigDecimal(roomNo);
		
		room.setRoomNo(roomNoBD);
		room.setRoomType("delux");
		room.setPerNightRt(2000);
		room.setAvailability("N");
		room.setRoomId(109);
			
		//assertEquals(false, service.updateRoom(room));
		
	}

	@Test
	public void testDeleteRoom() throws HotelException{
		assertEquals(true, service.deleteRoom(110));
	}
	
	@Test
	public void testDeleteRoom1() throws HotelException{
		assertEquals(true, service.deleteRoom(777));
	}

	@Test
	public void testGenerateHotelListReport() throws HotelException{
		assertNotEquals(0, service.generateHotelListReport().size());
	}
	
	@Test
	public void testGenerateHotelListReport1() throws HotelException{
		assertEquals(0, service.generateHotelListReport().size());
	}

	@Test
	public void testGenerateSpecificDateBookingReport() throws HotelException{
		DateTimeFormatter format=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		String startdate = "11/01/2017";
		LocalDate date1=LocalDate.parse(startdate,format);
		String enddate = "20/03/2017";
		LocalDate date2=LocalDate.parse(enddate,format);
		
		assertNotNull(service.generateSpecificDateBookingReport(date1, date2));
	}
	
	@Test
	public void testGenerateSpecificDateBookingReport1() throws HotelException{
		
		DateTimeFormatter format=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		String startdate = "11/04/2017";
		LocalDate date1=LocalDate.parse(startdate,format);
		String enddate = "20/12/2017";
		LocalDate date2=LocalDate.parse(enddate,format);
		assertNull(service.generateSpecificDateBookingReport(date1, date2));
	}
	
	@Test
	public void testViewRooms() throws HotelException{
		assertNotNull(service.viewRooms(1008));
	}
	
	@Test
	public void testViewRooms1() throws HotelException{
		assertEquals(1, service.viewRooms(2345).size());
	}

	@Test
	public void testGetRoom() throws HotelException{
		assertNotNull(service.getRoom(111));
	}
	
	@Test
	public void testGetRoom1() throws HotelException{
		assertNotNull(service.getRoom(66));
	}
	
	@After
	public void destroy()
	{
		service=null;
		dao=null;
	}


}
