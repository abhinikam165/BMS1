package com.capgemini.bms.bean;

import java.io.Serializable;
import javax.persistence.*;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;
import java.math.BigDecimal;
import java.util.List;
/**
 * The persistent class for the ROOM_DETAILS database table.
 * 
 */
@Component
@Entity
@Table(name="ROOM_DETAILS")
@NamedQuery(name="RoomDetail.findAll", query="SELECT r FROM RoomDetail r")
public class RoomDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="ROOM_DETAILS_ROOMID_GENERATOR", sequenceName="ROOM_SEQUENCE")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ROOM_DETAILS_ROOMID_GENERATOR")
	@Column(name="ROOM_ID")
	private int roomId;

	@NotEmpty(message="Please select availability")
	private String availability;

	@Column(name="PER_NIGHT_RT")
	private long perNightRt;

	@Column(name="ROOM_NO")
	private BigDecimal roomNo;

	@NotEmpty(message="Please select room type")
	@Column(name="ROOM_TYPE")
	private String roomType;

	//bi-directional many-to-one association to BookingDetail
	@OneToMany(mappedBy="roomDetail")
	private List<BookingDetail> bookingDetails;

	//bi-directional many-to-one association to Hotel
	
	@ManyToOne
	@JoinColumn(name="HOTEL_ID")
	private Hotel hotel;

	public RoomDetail() {
	}

	public int getRoomId() {
		return this.roomId;
	}

	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}

	public String getAvailability() {
		return this.availability;
	}

	public void setAvailability(String availability) {
		this.availability = availability;
	}

	public long getPerNightRt() {
		return this.perNightRt;
	}

	public void setPerNightRt(long perNightRt) {
		this.perNightRt = perNightRt;
	}

	public BigDecimal getRoomNo() {
		return this.roomNo;
	}

	public void setRoomNo(BigDecimal roomNo) {
		this.roomNo = roomNo;
	}

	public String getRoomType() {
		return this.roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public List<BookingDetail> getBookingDetails() {
		return this.bookingDetails;
	}

	public void setBookingDetails(List<BookingDetail> bookingDetails) {
		this.bookingDetails = bookingDetails;
	}

	public BookingDetail addBookingDetail(BookingDetail bookingDetail) {
		getBookingDetails().add(bookingDetail);
		bookingDetail.setRoomDetail(this);

		return bookingDetail;
	}

	public BookingDetail removeBookingDetail(BookingDetail bookingDetail) {
		getBookingDetails().remove(bookingDetail);
		bookingDetail.setRoomDetail(null);

		return bookingDetail;
	}

	public Hotel getHotel() {
		return this.hotel;
	}

	public void setHotel(Hotel hotel) {
		this.hotel = hotel;
	}

}