package com.capgemini.bms.service;

import java.time.LocalDate;
import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;




import com.capgemini.bms.bean.BookingDetail;
import com.capgemini.bms.bean.Hotel;
import com.capgemini.bms.bean.RoomDetail;
import com.capgemini.bms.dao.AdminDao;
import com.capgemini.bms.exception.HotelException;

@Service
@Transactional
public class AdminServiceImpl implements AdminService {
	
	@Autowired
	AdminDao dao;

	public void setDao(AdminDao dao)
	{
		this.dao = dao;
	}
	
	@Override
	public boolean addHotel(Hotel hotel) throws HotelException {
		return dao.addHotel(hotel);
	}

	@Override
	public ArrayList<Hotel> getHotelList() throws HotelException {
		return dao.getHotelList();
	}

	@Override
	public Hotel getHotels(int hotelId) throws HotelException {
		return dao.getHotels(hotelId);
	}

	@Override
	public boolean deleteHotel(int hotelId) throws HotelException {
		return dao.deleteHotel(hotelId);
	}

	@Override
	public boolean updateHotel(Hotel hotelNew) throws HotelException {
		return dao.updateHotel(hotelNew);
	}

	@Override
	public boolean addroom(RoomDetail room) throws HotelException {
		return dao.addroom(room);
	}

	@Override
	public boolean updateRoom(int roomId) throws HotelException {
		return dao.updateRoom(roomId);
	}

	@Override
	public boolean deleteRoom(int roomId) throws HotelException {
		return dao.deleteRoom(roomId);
	}

	@Override
	public ArrayList<Hotel> generateHotelListReport() throws HotelException {
		return dao.generateHotelListReport();
	}

	@Override
	public ArrayList<BookingDetail> generateSpecificDateBookingReport(
			LocalDate startDate, LocalDate endDate) throws HotelException {
		return dao.generateSpecificDateBookingReport(startDate, endDate);
	}

	@Override
	public ArrayList<BookingDetail> generateSpecificHotelBookingReport(int hotelId) throws HotelException {
		return dao.generateSpecificHotelBookingReport(hotelId);
	}

	@Override
	public ArrayList<RoomDetail> viewRooms(int hotelId) throws HotelException {
		return dao.viewRooms(hotelId);
	}

	@Override
	public RoomDetail getRoom(int roomId) throws HotelException {
		return dao.getRoom(roomId);
	}

	@Override
	public boolean deleteRoomOnHotelId(Hotel bean) throws HotelException {
		return dao.deleteRoomOnHotelId(bean);
	}

	@Override
	public boolean deleteBookingOnRoom(int roomId) throws HotelException {
		return dao.deleteBookingOnRoom(roomId);
	}

	@Override
	public ArrayList<RoomDetail> viewRoomstoDelete(int hotelId)
			throws HotelException {
		// TODO Auto-generated method stub
		return dao.viewRoomstoDelete(hotelId);
	}
	

	
}
