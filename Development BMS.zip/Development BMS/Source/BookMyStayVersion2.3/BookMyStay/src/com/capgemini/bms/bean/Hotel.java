package com.capgemini.bms.bean;

import java.io.Serializable;

import javax.persistence.*;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;


/**
 * The persistent class for the HOTEL database table.
 * 
 */
@Component
@Entity
@Table(name="hotel")
@NamedQuery(name="Hotel.findAll", query="SELECT h FROM Hotel h")
public class Hotel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="HOTEL_HOTELID_GENERATOR", sequenceName="HOTEL_SEQUENCE")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="HOTEL_HOTELID_GENERATOR")
	@Column(name="HOTEL_ID")
	private int hotelId;

	@Column(name="AVG_RATE")
	private BigDecimal avgRate;
	
	
	@Column(name="DISCOUNT_PERCENT")
	private BigDecimal discountPercent;
	
	@Email(message="please enter valid email id")
	@NotEmpty(message="Please enter email")
	private String email;

	private BigDecimal fax;

	@NotEmpty(message="Please enter Hotel Address")
	@Pattern(regexp="[a-zA-Z0-9 //s]{1,50}",message="Please enter valid address")
	@Column(name="HOTEL_ADDRESS")
	private String hotelAddress;

	@NotEmpty(message="Please select city")
	@Column(name="HOTEL_CITY")
	private String hotelCity;

	@NotEmpty(message="Please describe hotel")
	@Pattern(regexp="[a-zA-Z0-9 //s]{1,50}")
	@Column(name="HOTEL_DESC")
	private String hotelDesc;

	@NotEmpty(message="Please enter hotel name")
	@Pattern(regexp="[a-zA-Z //s]{1,20}",message="Please enter valid name")
	@Column(name="HOTEL_NAME")
	private String hotelName;


	@Column(name="HOTEL_PHN_NO1")
	private BigDecimal hotelPhnNo1;


	@Column(name="HOTEL_PHN_NO2")
	private BigDecimal hotelPhnNo2;
	
	private BigDecimal rating;

	//bi-directional many-to-one association to RoomDetail
	@OneToMany(mappedBy="hotel")
	private List<RoomDetail> roomDetails;

	public Hotel() {
	}

	public int getHotelId() {
		return this.hotelId;
	}

	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}

	public BigDecimal getAvgRate() {
		return this.avgRate;
	}

	public void setAvgRate(BigDecimal avgRate) {
		this.avgRate = avgRate;
	}

	public BigDecimal getDiscountPercent() {
		return this.discountPercent;
	}

	public void setDiscountPercent(BigDecimal discountPercent) {
		this.discountPercent = discountPercent;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public BigDecimal getFax() {
		return this.fax;
	}

	public void setFax(BigDecimal fax) {
		this.fax = fax;
	}

	public String getHotelAddress() {
		return this.hotelAddress;
	}

	public void setHotelAddress(String hotelAddress) {
		this.hotelAddress = hotelAddress;
	}

	public String getHotelCity() {
		return this.hotelCity;
	}

	public void setHotelCity(String hotelCity) {
		this.hotelCity = hotelCity;
	}

	public String getHotelDesc() {
		return this.hotelDesc;
	}

	public void setHotelDesc(String hotelDesc) {
		this.hotelDesc = hotelDesc;
	}

	public String getHotelName() {
		return this.hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	public BigDecimal getHotelPhnNo1() {
		return this.hotelPhnNo1;
	}

	public void setHotelPhnNo1(BigDecimal hotelPhnNo1) {
		this.hotelPhnNo1 = hotelPhnNo1;
	}

	public BigDecimal getHotelPhnNo2() {
		return this.hotelPhnNo2;
	}

	public void setHotelPhnNo2(BigDecimal hotelPhnNo2) {
		this.hotelPhnNo2 = hotelPhnNo2;
	}

	public BigDecimal getRating() {
		return this.rating;
	}

	public void setRating(BigDecimal rating) {
		this.rating = rating;
	}

	public List<RoomDetail> getRoomDetails() {
		return this.roomDetails;
	}

	public void setRoomDetails(List<RoomDetail> roomDetails) {
		this.roomDetails = roomDetails;
	}

	public RoomDetail addRoomDetail(RoomDetail roomDetail) {
		getRoomDetails().add(roomDetail);
		roomDetail.setHotel(this);

		return roomDetail;
	}

	public RoomDetail removeRoomDetail(RoomDetail roomDetail) {
		getRoomDetails().remove(roomDetail);
		roomDetail.setHotel(null);

		return roomDetail;
	}

}